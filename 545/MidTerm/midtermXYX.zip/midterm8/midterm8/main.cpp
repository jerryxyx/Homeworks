//
//  main.cpp
//  midterm8
//
//  Created by 夏宇轩 on 2/27/17.
//  Copyright (c) 2017 夏宇轩. All rights reserved.
//

#include <iostream>

int main(int argc, const char * argv[]) {
    // insert code here...
    for(int i=1;i<=100;i=i+2){
        std::cout<<i<<",";
    }
    return 0;
}
